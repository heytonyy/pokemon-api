import React from 'react'
import style from './App.module.css'
import Form from './components/Form'

export default function App() {

  return (
    <div className={style.App}>
      <Form />
    </div>
  )
}
