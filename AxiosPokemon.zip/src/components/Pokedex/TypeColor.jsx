import styled from "styled-components";

const coloredType = styled.span`
    color: ${props => props.color};
`
export default coloredType