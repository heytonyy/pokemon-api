import React from 'react'

const Form = () => {
  return (
    <div>Form</div>
  )
}

export default Form