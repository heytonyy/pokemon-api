import React from 'react'
import Pokedex from './components/Pokedex/Pokedex'
import '../src/App.css'

export default function App() {
  return (
    <>
        <Pokedex />
    </>
  )
}
